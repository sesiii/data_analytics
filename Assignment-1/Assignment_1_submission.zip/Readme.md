# Data Analytics Assignment 

The colab Link is 
https://colab.research.google.com/drive/1eDUgB0gbqow8Fqx25Uirm4CyuN3eNp4c#scrollTo=sXj9CE-W6anf